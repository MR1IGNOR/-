import json
import os
from datetime import datetime

def save_drone_data(drone_data, filename="drone_data.json"):
    """Сохраняет данные дрона в JSON файл"""
    try:
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        # Форматирование данных согласно требованиям
        formatted_data = {
            "drone_id": drone_data.get("drone_id", "BVS-001"),
            "alert_id": drone_data.get("alert_id", f"FIRE-{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}"),
            "coordinates": {
                "latitude": drone_data["coordinates"]["latitude"],
                "longitude": drone_data["coordinates"]["longitude"],
                "altitude": drone_data["coordinates"].get("altitude", 0),
                "accuracy_m": drone_data["coordinates"].get("accuracy_m", 20.0)
            },
            "timestamp": drone_data.get("timestamp", datetime.now().isoformat() + "Z")
        }
        
        with open(filename, "w", encoding="utf-8") as file:
            json.dump(formatted_data, file, ensure_ascii=False, indent=4)
        
        print(f"Данные сохранены в {filename}")
        return True
        
    except Exception as e:
        print(f"Ошибка сохранения JSON: {e}")
        return False

def load_drone_data(filename="drone_data.json"):
    """Загружает данные дрона из JSON файла"""
    try:
        if os.path.exists(filename):
            with open(filename, "r", encoding="utf-8") as file:
                return json.load(file)
        return None
    except Exception as e:
        print(f"Ошибка загрузки JSON: {e}")
        return None