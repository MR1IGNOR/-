from datetime import datetime
import time
import requests
import os

try:
    from gps3 import gps3
    GPS_AVAILABLE = True
except ImportError:
    GPS_AVAILABLE = False
    print("GPS3 не установлен, используется только IP локация")

def get_gps_location(timeout=10):
    """Получение местоположения через GPS модуль с таймаутом"""
    if not GPS_AVAILABLE:
        return None
        
    try:
        gps_socket = gps3.GPSDSocket()
        data_stream = gps3.DataStream()
        gps_socket.connect()
        gps_socket.watch()
        
        print("Поиск GPS сигнала...")
        start_time = time.time()
        
        for new_data in gps_socket:
            if new_data:
                data_stream.unpack(new_data)
                if (data_stream.TPV['lat'] != 'n/a' and 
                    data_stream.TPV['lon'] != 'n/a' and
                    data_stream.TPV['lat'] is not None and
                    data_stream.TPV['lon'] is not None):
                    
                    # Получаем высоту, если доступна
                    altitude = 'n/a'
                    if (data_stream.TPV['alt'] != 'n/a' and 
                        data_stream.TPV['alt'] is not None):
                        altitude = float(data_stream.TPV['alt'])
                    
                    return {
                        'latitude': float(data_stream.TPV['lat']),
                        'longitude': float(data_stream.TPV['lon']),
                        'altitude': altitude,
                        'source': 'GPS',
                        'time': datetime.now().isoformat(),
                        'satellites': data_stream.TPV.get('mode', 'n/a')
                    }
            
            # Проверка таймаута
            if time.time() - start_time > timeout:
                print("Таймаут поиска GPS сигнала")
                break
                
            time.sleep(1)
            
    except Exception as e:
        print(f"Ошибка GPS: {e}")
        return None
    finally:
        try:
            gps_socket.close()
        except:
            pass
    return None

def get_ip_location():
    """Получение местоположения по IP адресу"""
    try:
        print("Получение местоположения по IP...")
        response = requests.get('http://ip-api.com/json/', timeout=10)
        data = response.json()
        
        if data['status'] == 'success':
            # Для IP метода получаем приблизительную высоту через дополнительный API
            altitude = get_altitude_from_ip(data['lat'], data['lon'])
            
            return {
                'latitude': data['lat'],
                'longitude': data['lon'],
                'altitude': altitude,
                'source': 'IP',
                'time': datetime.now().isoformat(),
                'city': data.get('city', 'Неизвестно'),
                'country': data.get('country', 'Неизвестно'),
                'region': data.get('regionName', 'Неизвестно'),
                'zip': data.get('zip', 'Неизвестно')
            }
    except Exception as e:
        print(f"Ошибка получения местоположения по IP: {e}")
    return None

def get_altitude_from_ip(lat, lon):
    """Получение высоты над уровнем моря по координатам"""
    try:
        # Используем Open-Elevation API для получения высоты
        response = requests.get(
            f'https://api.open-elevation.com/api/v1/lookup?locations={lat},{lon}',
            timeout=5
        )
        elevation_data = response.json()
        
        if 'results' in elevation_data and len(elevation_data['results']) > 0:
            return round(elevation_data['results'][0]['elevation'], 2)
        
    except Exception as e:
        print(f"Ошибка получения высоты: {e}")
    
    # Альтернативный метод - простой геоидальный расчет (приблизительный)
    try:
        # Базовое приближение для большинства мест
        return round(calculate_approximate_altitude(lat, lon), 2)
    except:
        return 0.0  # Возвращаем 0 вместо 'n/a' для удобства расчетов

def calculate_approximate_altitude(lat, lon):
    """Приблизительный расчет высоты (упрощенный)"""
    # Это очень упрощенная модель, для точных данных лучше использовать API
    # Возвращаем 0 для прибрежных районов и небольшую высоту для внутренних
    if 44 < lat < 46 and 38 < lon < 40:  # Примерно Краснодарский край
        return 30.0
    elif 55 < lat < 56 and 37 < lon < 38:  # Примерно Москва
        return 150.0
    else:
        return 50.0  # Средняя высота по умолчанию

def format_altitude(altitude):
    """Форматирование вывода высоты"""
    if altitude == 'n/a':
        return "Недоступно"
    elif isinstance(altitude, (int, float)):
        return f"{altitude} м над ур. моря"
    else:
        return str(altitude)

def get_current_gps_coordinates():
    """Получение текущих GPS координат для детектора"""
    location = get_gps_location(timeout=10)
    if not location:
        location = get_ip_location()
    
    if location:
        # Преобразуем altitude в число, если это строка 'n/a'
        altitude = location.get('altitude', 0)
        if altitude == 'n/a':
            altitude = 0
        
        return (location['latitude'], location['longitude'], altitude)
    return None

def get_drone_position():
    """Получение полной позиции дрона для системы детекции"""
    location = get_gps_location(timeout=8)
    if not location:
        location = get_ip_location()
    
    if location:
        return {
            'latitude': location['latitude'],
            'longitude': location['longitude'],
            'altitude': location.get('altitude', 100),  # 100м по умолчанию
            'source': location.get('source', 'unknown'),
            'timestamp': location.get('time', datetime.now().isoformat())
        }
    return None

if __name__ == "__main__":
    print("=== Запуск системы определения местоположения ===")
    print(f"Текущая рабочая директория: {os.getcwd()}")
    print(f"GPS доступен: {GPS_AVAILABLE}")
    print("-" * 50)
    
    location_data = get_gps_location(timeout=15)
    
    if not location_data:
        print("GPS недоступен, пробуем метод по IP...")
        location_data = get_ip_location()
    
    if location_data:
        print("\n" + "=" * 50)
        print("✓ ДАННЫЕ О МЕСТОПОЛОЖЕНИИ ПОЛУЧЕНЫ!")
        print("=" * 50)
        print(f"Широта: {location_data['latitude']}")
        print(f"Долгота: {location_data['longitude']}")
        print(f"Высота: {format_altitude(location_data.get('altitude', 'n/a'))}")
        print(f"Источник: {location_data.get('source', 'unknown')}")
        print(f"Время: {location_data['time']}")
        
        # Дополнительная информация для GPS
        if location_data['source'] == 'GPS':
            print(f"Спутники: {location_data.get('satellites', 'n/a')}")
        
        # Дополнительная информация для IP метода
        if location_data['source'] == 'IP':
            print(f"Город: {location_data.get('city', 'Неизвестно')}")
            print(f"Регион: {location_data.get('region', 'Неизвестно')}")
            print(f"Страна: {location_data.get('country', 'Неизвестно')}")
            print(f"Индекс: {location_data.get('zip', 'Неизвестно')}")
        
        print(f"\nКоординаты: {location_data['latitude']}, {location_data['longitude']}")
        print("=" * 50)
        
        # Тест новых функций
        print("\nТест функций для системы детекции:")
        coords = get_current_gps_coordinates()
        if coords:
            print(f"Координаты для детектора: {coords}")
        
        position = get_drone_position()
        if position:
            print(f"Позиция дрона: {position}")
        
    else:
        print("\n✗ Не удалось получить данные о местоположении")
    
    print("\n=== Завершение работы ===")