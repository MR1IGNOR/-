import sys
import os
import time
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from gui.GUI import DroneInfoApp
from sensors.GPS_info import get_gps_location, get_ip_location
from video.SmokeDetection import SmokeDetector
from json_utils.json_handler import save_drone_data, load_drone_data
from PyQt5.QtWidgets import QApplication

class DroneMonitoringSystem:
    def __init__(self):
        self.drone_data = None
        self.smoke_detector = SmokeDetector()
        self.update_interval = 5  # seconds
        
    def get_current_location(self):
        """Получение текущих координат дрона"""
        location_data = get_gps_location(timeout=10)
        if not location_data:
            location_data = get_ip_location()
        return location_data
    
    def create_alert_data(self, fire_coords, confidence):
        """Создание данных для оповещения о пожаре"""
        location_data = self.get_current_location()
        
        if location_data:
            return {
                "drone_id": "BVS-001",
                "alert_id": f"FIRE-{time.strftime('%Y-%m-%d-%H-%M-%S')}",
                "coordinates": {
                    "latitude": fire_coords[0],
                    "longitude": fire_coords[1],
                    "altitude": location_data.get('altitude', 0),
                    "accuracy_m": 15.0
                },
                "detection_confidence": confidence,
                "drone_position": {
                    "latitude": location_data['latitude'],
                    "longitude": location_data['longitude'],
                    "altitude": location_data.get('altitude', 0)
                },
                "timestamp": time.strftime('%Y-%m-%dT%H:%M:%SZ')
            }
        return None
    
    def run_detection_cycle(self):
        """Цикл обнаружения пожара"""
        print("Запуск системы обнаружения пожара...")
        
        while True:
            try:
                # Запуск детекции на несколько кадров
                fire_detected, fire_coords, confidence = self.smoke_detector.detect_fire()
                
                if fire_detected:
                    print(f"🚨 Обнаружен пожар! Координаты: {fire_coords}")
                    
                    # Сохранение данных в JSON
                    alert_data = self.create_alert_data(fire_coords, confidence)
                    if alert_data:
                        save_drone_data(alert_data, "fire_alert.json")
                        print("Данные о пожаре сохранены")
                        
                        # Запуск GUI с данными о пожаре
                        self.launch_gui("fire_alert.json")
                        break
                
                time.sleep(self.update_interval)
                
            except KeyboardInterrupt:
                print("Остановка системы...")
                break
            except Exception as e:
                print(f"Ошибка: {e}")
                time.sleep(self.update_interval)
    
    def launch_gui(self, json_file):
        """Запуск GUI с данными о пожаре"""
        app = QApplication(sys.argv)
        window = DroneInfoApp(json_file)
        window.show()
        sys.exit(app.exec_())

def main():
    """Основная функция приложения"""
    print("=== Система мониторинга дрона и обнаружения пожаров ===")
    
    system = DroneMonitoringSystem()
    system.run_detection_cycle()

if __name__ == "__main__":
    main()