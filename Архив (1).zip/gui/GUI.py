import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QFrame, QScrollArea, QPushButton)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPixmap
from json_utils.json_handler import load_drone_data

class DroneInfoApp(QMainWindow):
    def __init__(self, json_file="fire_alert.json"):
        super().__init__()
        self.setWindowTitle("Информация о обнаружении пожара")
        self.setGeometry(100, 100, 900, 600)
        self.json_file = json_file
        
        self.json_data = self.load_data()
        self.initUI()
        
        # Таймер для обновления данных
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_data)
        self.timer.start(5000)  # Обновление каждые 5 секунд
        
    def load_data(self):
        """Загрузка данных из JSON файла"""
        data = load_drone_data(self.json_file)
        if not data:
            # Данные по умолчанию
            data = {
                "drone_id": "BVS-001",
                "alert_id": "FIRE-2025-08-12-14:30:00",
                "coordinates": {
                    "latitude": 55.751244,
                    "longitude": 37.618423,
                    "altitude": 150.5,
                    "accuracy_m": 20.0
                },
                "timestamp": "2025-08-12T14:30:00Z"
            }
        return data
        
    def update_data(self):
        """Обновление данных из JSON файла"""
        new_data = load_drone_data(self.json_file)
        if new_data:
            self.json_data = new_data
            self.refresh_ui()
        
    def refresh_ui(self):
        """Обновление интерфейса"""
        # Здесь можно добавить логику обновления виджетов
        print("Данные обновлены")

        
    def initUI(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Основной layout
        main_layout = QHBoxLayout(central_widget)
        
        # Левая часть - информация
        info_frame = QFrame()
        info_frame.setFrameStyle(QFrame.Box)
        info_frame.setLineWidth(1)
        info_layout = QVBoxLayout(info_frame)
        
        # Заголовок
        title_label = QLabel("Информация о дроне")
        title_label.setFont(QFont("Arial", 16, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        info_layout.addWidget(title_label)
        
        # Отображение данных из JSON
        info_layout.addWidget(self.create_info_label("ID дрона:", self.json_data["drone_id"]))
        info_layout.addWidget(self.create_info_label("ID тревоги:", self.json_data["alert_id"]))
        info_layout.addWidget(self.create_info_label("Широта:", f"{self.json_data['coordinates']['latitude']:.6f}"))
        info_layout.addWidget(self.create_info_label("Долгота:", f"{self.json_data['coordinates']['longitude']:.6f}"))
        info_layout.addWidget(self.create_info_label("Высота:", f"{self.json_data['coordinates']['altitude']} м"))
        info_layout.addWidget(self.create_info_label("Точность:", f"{self.json_data['coordinates']['accuracy_m']} м"))
        info_layout.addWidget(self.create_info_label("Время:", self.json_data["timestamp"]))
        
        info_layout.addStretch()
        
        # Правая часть - фото
        photo_frame = QFrame()
        photo_frame.setFrameStyle(QFrame.Box)
        photo_frame.setLineWidth(1)
        photo_layout = QVBoxLayout(photo_frame)
        
        photo_title = QLabel("Фото с дрона")
        photo_title.setFont(QFont("Arial", 16, QFont.Bold))
        photo_title.setAlignment(Qt.AlignCenter)
        photo_layout.addWidget(photo_title)
        
        # Заглушка для фото (можно заменить на реальное изображение)
        photo_label = QLabel()
        photo_label.setAlignment(Qt.AlignCenter)
        photo_label.setStyleSheet("""
            QLabel {
                background-color: #f0f0f0;
                border: 2px dashed #ccc;
                min-width: 300px;
                min-height: 300px;
            }
        """)
        photo_label.setText("Фото будет здесь\n(заглушка)")
        photo_label.setFont(QFont("Arial", 12))
        
        photo_layout.addWidget(photo_label)
        
        # Добавляем обе части в основной layout
        main_layout.addWidget(info_frame, 1)
        main_layout.addWidget(photo_frame, 1)
        
    def create_info_label(self, title, value):
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(10, 5, 10, 5)
        
        title_label = QLabel(title)
        title_label.setFont(QFont("Arial", 12, QFont.Bold))
        title_label.setMinimumWidth(120)
        
        value_label = QLabel(str(value))
        value_label.setFont(QFont("Arial", 12))
        value_label.setWordWrap(True)
        
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addStretch()
        
        return widget

def main():
    app = QApplication(sys.argv)
    window = DroneInfoApp()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()